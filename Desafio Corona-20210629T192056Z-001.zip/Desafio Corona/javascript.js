var btn = document.querySelector(".show-or-hide");
var btn2 = document.querySelector(".show-or-hide2");
var btn3 = document.querySelector(".show-or-hide3");
var btn4 = document.querySelector(".show-or-hide4");
var btn5 = document.querySelector(".show-or-hide5");

var conti = document.querySelector(".conti");
var conti2 = document.querySelector(".conti2");
var conti3 = document.querySelector(".conti3");
var conti4 = document.querySelector(".conti4");
var conti5 = document.querySelector(".conti5");

btn.addEventListener("click", function() {

	if(conti.style.display === "block") {
		conti.style.display = "none";

	} else {
		conti.style.display = "block";
	}

});

btn2.addEventListener("click", function() {

	if(conti2.style.display === "block") {
		conti2.style.display = "none";

	} else {
		conti2.style.display = "block";
	}

});

btn3.addEventListener("click", function() {

	if(conti3.style.display === "block") {
		conti3.style.display = "none";

	} else {
		conti3.style.display = "block";
	}

});

btn4.addEventListener("click", function() {

	if(conti4.style.display === "block") {
		conti4.style.display = "none";

	} else {
		conti4.style.display = "block";
	}

});

btn5.addEventListener("click", function() {

	if(conti5.style.display === "block") {
		conti5.style.display = "none";

	} else {
		conti5.style.display = "block";
	}

});

